package com.list.articals.articalslistdetails.model;

import android.os.Parcel;
import android.os.Parcelable;

public class ArticleParcelableModel implements Parcelable {
    int rank;
    int rank_last_week;
    String publisher;
    String description;
    int price;
    String title;
    String author;
    String contributor;
    String contributor_note;
    int book_image_width;
    int book_image_height;

    @Override
    public int describeContents() {
        return 0;
    }

    // Storing the Movie data to Parcel object
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(rank);
        dest.writeInt(rank_last_week);
        dest.writeString(publisher);
        dest.writeString(description);
        dest.writeInt(price);
        dest.writeString(title);
        dest.writeString(author);
        dest.writeString(contributor);
        dest.writeString(contributor_note);
        dest.writeInt(book_image_width);
        dest.writeInt(book_image_height);
    }

    // A constructor that initializes the Movie object
    public ArticleParcelableModel(int rank,
                                  int rank_last_week,
                                  String publisher,
                                  String description,
                                  int price,
                                  String title,
                                  String author,
                                  String contributor,
                                  String contributor_note,
                                  int book_image_width,
                                  int book_image_height) {

        this.rank = rank;
        this.rank_last_week = rank_last_week;
        this.publisher = publisher;
        this.description = description;
        this.price = price;
        this.title = title;
        this.author = author;
        this.contributor = contributor;
        this.contributor_note = contributor_note;
        this.book_image_width = book_image_width;
        this.book_image_height = book_image_height;
    }

    /**
     * Retrieving Movie data from Parcel object
     * This constructor is invoked by the method createFromParcel(Parcel source) of
     * the object CREATOR
     **/
    private ArticleParcelableModel(Parcel in){

        this.rank = in.readInt();
        this.rank_last_week = in.readInt();
        this.publisher = in.readString();
        this.description = in.readString();
        this.price = in.readInt();
        this.title = in.readString();
        this.author = in.readString();
        this.contributor = in.readString();
        this.contributor_note = in.readString();
        this.book_image_width = in.readInt();
        this.book_image_height = in.readInt();
    }

    public static final Parcelable.Creator<ArticleParcelableModel> CREATOR = new Parcelable.Creator<ArticleParcelableModel>() {
        @Override
        public ArticleParcelableModel createFromParcel(Parcel source) {
            return new ArticleParcelableModel(source);
        }

        @Override
        public ArticleParcelableModel[] newArray(int size) {
            return new ArticleParcelableModel[size];
        }
    };
}
