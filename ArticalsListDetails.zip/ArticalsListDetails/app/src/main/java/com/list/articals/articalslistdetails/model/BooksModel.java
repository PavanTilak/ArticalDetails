package com.list.articals.articalslistdetails.model;

import android.os.Parcel;
import android.os.Parcelable;

public class BooksModel implements Parcelable {

    @Override
    public int describeContents() {
        return 0;
    }

    // Storing the Movie data to Parcel object
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(rank);
        dest.writeInt(rank_last_week);
        dest.writeString(publisher);
        dest.writeString(description);
        dest.writeInt(price);
        dest.writeString(title);
        dest.writeString(author);
        dest.writeString(contributor);
        dest.writeString(contributor_note);
        dest.writeInt(book_image_width);
        dest.writeInt(book_image_height);
    }

    /**
     * Retrieving Movie data from Parcel object
     * This constructor is invoked by the method createFromParcel(Parcel source) of
     * the object CREATOR
     **/
    private BooksModel(Parcel in){

        this.rank = in.readInt();
        this.rank_last_week = in.readInt();
        this.publisher = in.readString();
        this.description = in.readString();
        this.price = in.readInt();
        this.title = in.readString();
        this.author = in.readString();
        this.contributor = in.readString();
        this.contributor_note = in.readString();
        this.book_image_width = in.readInt();
        this.book_image_height = in.readInt();
    }

    public static final Parcelable.Creator<BooksModel> CREATOR = new Parcelable.Creator<BooksModel>() {
        @Override
        public BooksModel createFromParcel(Parcel source) {
            return new BooksModel(source);
        }

        @Override
        public BooksModel[] newArray(int size) {
            return new BooksModel[size];
        }
    };

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    int rank;

    public int getRank_last_week() {
        return rank_last_week;
    }

    public void setRank_last_week(int rank_last_week) {
        this.rank_last_week = rank_last_week;
    }

    int rank_last_week;

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    String publisher;
    String description;

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    int price;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    String title;

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    String author;

    public String getContributor() {
        return contributor;
    }

    public void setContributor(String contributor) {
        this.contributor = contributor;
    }

    String contributor;

    public String getContributor_note() {
        return contributor_note;
    }

    public void setContributor_note(String contributor_note) {
        this.contributor_note = contributor_note;
    }

    String contributor_note;
    int book_image_width;
    int book_image_height;

    public BooksModel(int rank,
                      int rank_last_week,
                      String publisher,
                      String description,
                      int price,
                      String title,
                      String author,
                      String contributor,
                      String contributor_note,
                      int book_image_width,
                      int book_image_height) {

        this.rank = rank;
        this.rank_last_week = rank_last_week;
                this.publisher = publisher;
                this.description = description;
                this.price = price;
                this.title = title;
                this.author = author;
                this.contributor = contributor;
                this.contributor_note = contributor_note;
                this.book_image_width = book_image_width;
                this.book_image_height = book_image_height;


    }

}
