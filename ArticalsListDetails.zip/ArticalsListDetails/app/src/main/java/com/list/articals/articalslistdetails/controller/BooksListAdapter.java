package com.list.articals.articalslistdetails.controller;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.list.articals.articalslistdetails.MainActivity;
import com.list.articals.articalslistdetails.R;
import com.list.articals.articalslistdetails.model.BooksModel;
import com.list.articals.articalslistdetails.view.ArticleDetailsScreen;

import java.util.ArrayList;

public class BooksListAdapter extends BaseAdapter {

    private Activity activity;
    ArrayList<BooksModel> booksList = null;

    private static LayoutInflater inflater = null;

    public BooksListAdapter(Activity activity, ArrayList<BooksModel> articles_list) {
        this.activity = activity;
        this.booksList = articles_list;

        inflater = (LayoutInflater) activity
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    public int getCount() {
        return booksList.size();
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        View vi = convertView;
        if (convertView == null)
            vi = inflater.inflate(R.layout.row_listitem, null);
        vi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity, ArticleDetailsScreen.class);
                intent.putExtra("BookList", booksList.get(position));
                activity.startActivity(intent);
            }
        });

        TextView publisher = vi.findViewById(R.id.publisher);
        publisher.setText("publisher : "+booksList.get(position).getPublisher());

        TextView description = vi.findViewById(R.id.description);
        description.setText("description : "+booksList.get(position).getDescription());

        TextView title = vi.findViewById(R.id.title);
        title.setText("title : "+booksList.get(position).getTitle());

        TextView author = vi.findViewById(R.id.author);
        author.setText("author : "+booksList.get(position).getAuthor());

        return vi;

    }
}
