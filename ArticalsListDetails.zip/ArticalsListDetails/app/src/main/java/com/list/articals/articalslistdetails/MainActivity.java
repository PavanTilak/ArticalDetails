package com.list.articals.articalslistdetails;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import com.list.articals.articalslistdetails.controller.BooksListAdapter;
import com.list.articals.articalslistdetails.model.BooksModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ProgressDialog progressDialog;
    ArrayList<BooksModel> booksList = null;
    ListView articles_list=null;
    BooksListAdapter booksAdapter =null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getAllIds();
        new RetrieveArticlesTask().execute();
    }

    private void getAllIds(){
        articles_list = (ListView) findViewById(R.id.articles_list);
    }

    private void showDialog() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Downloading Articles ,Please wait...");
        progressDialog.show();
    }

    private void dismissDialog() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

    private void parseJsonData(String response) {
        try {
            booksList = new ArrayList<BooksModel>();
            JSONObject jsonObj = new JSONObject(response);
            int num_results = jsonObj.getInt("num_results");
            JSONObject resultsObj = jsonObj.getJSONObject("results");

            JSONArray booksArray = resultsObj.getJSONArray("books");
            for (int i = 0; i < booksArray.length(); i++) {

                JSONObject bookJSONObject = booksArray.getJSONObject(i);
                BooksModel mBooksModelObj = new BooksModel(
                        bookJSONObject.getInt("rank"),
                        bookJSONObject.getInt("rank_last_week"),
                        bookJSONObject.getString("publisher"),
                        bookJSONObject.getString("description"),
                        bookJSONObject.getInt("price"),
                        bookJSONObject.getString("title"),
                        bookJSONObject.getString("author"),
                        bookJSONObject.getString("contributor"),
                        bookJSONObject.getString("contributor_note"),
                        bookJSONObject.getInt("book_image_width"),
                        bookJSONObject.getInt("book_image_height")
                );
                booksList.add(mBooksModelObj);
            }//for

        } catch (JSONException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    class RetrieveArticlesTask extends AsyncTask<Void, Void, String> {

        protected void onPreExecute() {
            showDialog();
        }

        protected String doInBackground(Void... urls) {

            try {
                URL url = new URL("https://api.nytimes.com/svc/books/v3/lists/current/hardcover-fiction.json?api-key=nNITQAgnmmV5AZCkLqGGjeqqsLkbqv2q");///API_URL + "email=" + email + "&apiKey=" + API_KEY);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();

                    parseJsonData(stringBuilder.toString());

                } finally {
                    urlConnection.disconnect();
                }
            } catch (Exception e) {
                Log.e("ERROR", e.getMessage(), e);
            }
            return "";
        }

        protected void onPostExecute(String response) {
            /*if (response == null) {
                Toast.makeText(MainActivity.this, "", Toast.LENGTH_LONG).show();
                response = "THERE WAS AN ERROR";
            }*/
            //display list items in listview

            booksAdapter = new BooksListAdapter(MainActivity.this, booksList);
            articles_list.setAdapter(booksAdapter);

            dismissDialog();
        }
    }
}
