package com.list.articals.articalslistdetails.view;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.list.articals.articalslistdetails.R;
import com.list.articals.articalslistdetails.model.BooksModel;

public class ArticleDetailsScreen extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_article_details_screen);

        BooksModel booksModel = (BooksModel) getIntent().getParcelableExtra("BookList");
        if (booksModel != null) {

            TextView rank = findViewById(R.id.rank);
            rank.setText("rank : "+booksModel.getRank());

            TextView price = findViewById(R.id.price);
            price.setText("price : "+booksModel.getPrice());

            TextView rank_last_week = findViewById(R.id.rank_last_week);
            rank_last_week.setText("rank_last_week : "+booksModel.getRank_last_week());

            TextView publisher = findViewById(R.id.publisher);
            publisher.setText("publisher : "+booksModel.getPublisher());

            TextView description = findViewById(R.id.description);
            description.setText("description : "+booksModel.getDescription());

            TextView title = findViewById(R.id.title);
            title.setText("title : "+booksModel.getTitle());

            TextView author = findViewById(R.id.author);
            author.setText("author : "+booksModel.getAuthor());
        }
    }
}
